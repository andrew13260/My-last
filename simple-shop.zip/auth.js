import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail } 
from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

window.signUp = () => {
  createUserWithEmailAndPassword(auth, email.value, password.value)
    .then(() => message.innerText = "Account created")
    .catch(e => message.innerText = e.message);
};

window.logIn = () => {
  signInWithEmailAndPassword(auth, email.value, password.value)
    .then(() => message.innerText = "Logged in")
    .catch(e => message.innerText = e.message);
};

window.resetPassword = () => {
  sendPasswordResetEmail(auth, email.value)
    .then(() => message.innerText = "Password reset email sent")
    .catch(e => message.innerText = e.message);
};
